# Além das Apostas
Aplicativo de apoio à prevenção de apostas, reconstrução financeira, fé e novos caminhos.

**Pare de apostar. Comece a construir.**

MVP V0.2: contador, dinheiro preservado, intervenção de 10 minutos, fé, reconstrução financeira, evolução e novos caminhos.
